-- ============================================================================
-- Localization System for RaidLootCounter
-- ============================================================================

local addonName, RLC = ...
RLC.L = {} -- Create localization table attached to the addon namespace or global RLC
